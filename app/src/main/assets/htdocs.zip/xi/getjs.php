<?php

if (isset($_GET['f'])){

  $info = new SplFileInfo($_GET['f']);
  if ($info->getExtension() == 'js'){
    echo file_get_contents($_GET['f']);
  }
}

?>

<?php

$template = array( 1 => 
'<repeat>
    <div class="<inputType />"><label><input type="<inputType />" name="<questionName />" id="<idName />" value="<optionKey />"<checked />><optionText /></label></div>
</repeat> 
<br/>
<br/>
<dkrfInput /><dkButton /> <rfButton />'
);

?>
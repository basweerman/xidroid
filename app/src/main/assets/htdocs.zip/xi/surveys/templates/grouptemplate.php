<?php

$template = array( 1 => 
'<repeat>
    <question />
</repeat>'
);

?>
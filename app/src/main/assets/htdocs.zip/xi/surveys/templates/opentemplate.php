<?php

$template = array( 1 => 
'<textarea style="<style />" class="form-control" name="<questionName />" id="<idName />"><value /></textarea>
<br/>
<br/>
<dkrfInput /><dkButton /> <rfButton />'
);

?>
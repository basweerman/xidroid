<?php

$template = array( 1 => 
'<input type=text style="<style />" class="form-control" name="<questionName />" id="<idName />" value="<value />">
<br/>
<br/>
<dkrfInput /><dkButton /> <rfButton />'
);

?>
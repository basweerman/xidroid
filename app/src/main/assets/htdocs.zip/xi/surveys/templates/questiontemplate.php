<?php

$template = array( 1 => 
'<errorMessage />
<!-- (<questionName />) <br/>-->
<questionText />
<hr>
<answerOption />'
);

?>
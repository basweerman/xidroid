<?php
//RULES
$survey_intro->ask();

?>

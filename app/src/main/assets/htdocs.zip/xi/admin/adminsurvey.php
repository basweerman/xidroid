<?php


class AdminSurvey extends Survey {
    
    

    
}



?>
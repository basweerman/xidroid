#!/system/bin/sh

export app="/data/data/xi.xidroid"
export sbin="${app}/services"
export assets="/sdcard/xidroid"
export busybox="${app}/busybox/sbin/busybox"

$busybox killall -SIGTERM lighttpd
$busybox killall -3 mysqld
$busybox killall -SIGTERM mysqld
$busybox killall -SIGTERM php-cgi

#$sbin/nginx/sbin/nginx \
#		-p $assets/conf/nginx -s stop
## anyway
#$busybox killall -SIGTERM nginx

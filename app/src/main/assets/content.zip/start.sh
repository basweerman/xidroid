#!/system/bin/sh


## application configuration
export app="/data/data/xi.xidroid"
export sbin="${app}/services"
export assets="/sdcard/xidroid"
export log="/sdcard/xidroid/logs/log.txt"
export busybox="${app}/busybox/sbin/busybox"
export daemon=$1
export port=$2

## PHP fastcgi env variables
export PHP_FCGI_CHILDERN=3
export PHP_FCGI_MAX_REQUEST=1000

## echo "start log" >> /sdcard/xidroid/logs/log.txt

NOW=$(date +"%m-%d-%Y %H:%M:%S")
echo $NOW "start log" >> $log


# change_server_port()
# {
# 	$busybox sed -i "s|^listen .*$|listen $1;|g" $assets/hosts/nginx/localhost_host.conf
# 	$busybox sed -i "s|^server.port .*$|server.port = $1|g" $assets/conf/lighttpd.conf
# }

## change permission

chmod 0755 $sbin/busybox/sbin/busybox 2>/dev/null
chmod 0755 $sbin/lighttpd/sbin/lighttpd 2>/dev/null
chmod 0755 $sbin/nginx/sbin/nginx 2>/dev/null
chmod 0755 $sbin/php/sbin/php-cgi 2>/dev/null
chmod 0755 $sbin/mysql/sbin/mysqld 2>/dev/null
chmod 0755 $sbin/mysql/sbin/mysql-monitor 2>/dev/null

chmod 0755 $sbin/tmp 2>/dev/null
chmod 0755 $app/stop.sh 2>/dev/null
## chmod 0755 $app/scripts/create_host.sh 2>/dev/null

## check for required file

## if $busybox test ! -e "$assets/conf/lighttpd.conf"; then
## 	$busybox cp $sbin/lighttpd/conf/lighttpd.conf $assets/conf
## fi

## if $busybox test ! -e "$assets/conf/php.ini"; then
## 	$busybox cp $sbin/php/conf/php.ini $assets/conf
## fi

## if $busybox test ! -e "$assets/conf/mysql.ini"; then
## 	$busybox cp $sbin/mysql/conf/mysql.ini $assets/conf
## fi

## if $busybox test ! -e "$assets/conf/nginx/conf/nginx.conf"; then
## 	$busybox rm $assets/conf/nginx/* 2>/dev/null
##     $busybox cp $sbin/nginx/conf -R $assets/conf/nginx
## 	$busybox rm $assets/hosts/nginx/localhost_host.conf 2>/dev/null
## fi

## if $busybox test ! -e "$assets/hosts/nginx/localhost_host.conf"; then
	## $busybox cp $sbin/nginx/conf/localhost_host.conf $assets/hosts/nginx
## fi

## if $busybox test ! -e "/mnt/sdcard/htdocs/index.php"; then
## 	$busybox cp $app/htdocs/* -R /mnt/sdcard/htdocs
## fi
# if busybox test ! -e "$assets/webui"; then

# 	$busybox sed -i "s{include $assets/webui/nginx/localost_droidphp_wi.conf;{\n{" $assets/conf/nginx/conf/nginx.conf
# 	hosts="#begin_hosts (do not remove this label!)"
# 	host_file="$hosts\ninclude $assets/webui/nginx/localost_droidphp_wi.conf;"
#   	$busybox sed -i "s{$hosts{$host_file{" $assets/conf/nginx/conf/nginx.conf

#   	$bustbox mkdir $assets/webui 2>/dev/null
#   	$busybox tar -xvf $app/scripts/webui.tar.gz -C $assets/webui 2>/dev/null
# fi

## execuate as deamon proccess
## echo "using $daemon as http daemon"

## update server port
#change_server_port $port

## execute server

## if $busybox test $daemon == "lighttpd"; then

 NOW=$(date +"%m-%d-%Y %H:%M:%S")
 echo $NOW "executing lighttpd" >> $log
  	$sbin/lighttpd/sbin/lighttpd \
  		-f $sbin/lighttpd/conf/lighttpd.conf \
  		-D 1>/dev/null 2>&1 & PID_LIGTTPD=$!


## fi

## nginx dont want to start as root
## if $busybox test $daemon == "nginx"; then

#NOW=$(date +"%m-%d-%Y %H:%M:%S")
#echo $NOW "executing nginx" >> $log

## 	echo "executing nginx"
# 	$sbin/nginx/sbin/nginx \
# 		-p $sbin/nginx/conf/nginx.conf
## fi

NOW=$(date +"%m-%d-%Y %H:%M:%S")
echo $NOW "executing php-cgi" >> $log
 $sbin/php/sbin/php-cgi \
 	-a -b $app/tmp/php.sock \
 	-c $sbin/php/conf/php.ini \
 	1>/dev/null 2>&1 & PID_PHP=$!
 

NOW=$(date +"%m-%d-%Y %H:%M:%S")
echo $NOW "executing mysqld" >> $log

$sbin/mysql/sbin/mysqld \
	--defaults-file=$sbin/mysql/conf/mysql.ini \
	--user=root \
	--language=$sbin/mysql/sbin/share/mysql/english \
	1>/dev/null 2>&1 & PID_MYSQL=$!


## debugging
NOW=$(date +"%m-%d-%Y %H:%M:%S")
echo $NOW "php=$PID_PHP mysql=$PID_MYSQL" >> $log
# echo $NOW "lighttpd=$PID_LIGTTPD php=$PID_PHP mysql=$PID_MYSQL" >> $log

#toolbox log ${1+"$@"}
